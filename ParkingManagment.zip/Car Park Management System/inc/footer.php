
<footer>
<p style="font-weight: bold; color: white;">Car Park Management | Copyright 2024</p>

</footer>
