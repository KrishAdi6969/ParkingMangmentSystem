<!doctype html>
<html lang="en">

<head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>

<style>
     body {
	 /*background-image: url("../body.JPG");*/
	 background: url(bg.jpg) center / cover
	 no-repeat;
	}
    /* Container styles */
    .container {
    max-width: 600px;
    margin: 40px auto;
    padding: 20px;
    background-color: #000000;
    color: #ffffff;
    
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    opacity: 0.7; /* Add this line to make the container slightly transparent */
}

    /* Form group styles */
   .form-group {
        margin-bottom: 20px;
    }

    /* Form control styles */
   .form-control {
        width: 100%;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    /* Button styles */
   .btn {
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        background-color: #4CAF50;
        color: #ffffff;
        cursor: pointer;
    }

   .btn:hover {
        background-color: #3e8e41;
    }

    /* Success button styles */
   .btn-success {
        background-color: #34C759;
    }

   .btn-success:hover {
        background-color: #2E865F;
    }

    /* Label styles */
    label {
        display: block;
        margin-bottom: 10px;
        font-weight: bold;
    }

    /* Input field styles */
    input[type="text"],
    input[type="email"],
    input[type="number"] {
        width: 100%;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    /* Input field hover effect */
    input[type="text"]:hover,
    input[type="email"]:hover,
    input[type="number"]:hover {
        border-color: #999999;
    }
</style>

<div class="container mt-5">
    <form action="pay.php" method="post">
        <div class="form-group">
            <label>Price:</label>
            RS. 120<input type="hidden" value="120" name="price"> <br><br>
            <label>Name:</label>
            <input class="form-control" type="text" name="customername"> <br>
            <label>Email:</label>
            <input class="form-control" type="email" name="email" id=""> <br>
            <label>Contact No:</label>
            <input class="form-control" type="number" name="phone"><br>
            <button type="submit" class="btn btn-success" name="submit">Pay Now</button>
        </div>
    </form>
</div>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>
</body>

</html>