<?php 
if (session_status() == PHP_SESSION_NONE) {
    session_start();
    include('../inc/connect.php');

    $phone = $_SESSION['phone'];
    $query = mysqli_query($connect, "SELECT * FROM zones WHERE phone='$phone' AND status='RESERVED'");
    $rows = mysqli_num_rows($query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Unbook Parking</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
            background-image: url('body.jpg');
            background-size: cover;
        }
        #container {
            width: 80%;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 50px;
        }
        h2 {
            margin-top: 0;
            color: #333;
        }
        form {
            max-width: 400px;
            margin: 0 auto;
        }
        label {
            display: block;
            margin-bottom: 10px;
            color: #666;
        }
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        input[type="submit"] {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        #header {
            background-image: url('header.jpg');
            background-size: cover;
            padding: 20px;
            color: #fff;
            text-align: center;
        }
        #footer {
            background-image: url('body.jpg');
            background-size: cover;
            padding: 20px;
            color: #fff;
            text-align: center;
        }
    </style>
</head>
<body>

<div id="container">
    <h1>Car Park Management System</h1>
</div>

<div id="container">
    <h2>Unbook Parking Lot</h2>

    <form method="post" action="process_unbook.php">
        <label for="booking">Select Booking to Unbook:</label>
        <select id="booking" name="booking">
            <?php
            while ($row = mysqli_fetch_array($query)) {
                echo "<option value='{$row['id']}'>{$row['street']} - {$row['plot']} - {$row['d1']}</option>";
            }
            ?>
        </select>
        <br><br>
        <input type="submit" value="Unbook Now">
    </form>
</div>

<div id="container">
    <p>&copy; 2024 Car Park Management System</p>
</div>

</body>
</html>

<?php
}
?>
