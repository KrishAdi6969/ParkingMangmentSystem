<ul class="collapsibleList">
						 <li>
						  <label for="mylist-node1" class="quick-links">Primary</label>
						  <input type="checkbox" id="mylist-node1" />
						  <ul>
								<li></li>
								<li><a href="">Class Five</a></li>
								<li><a href="">Class Six</a></li>
								<li><a href="">Class Seven</a></li>
								<li><a href="">Class Eight</a></li>
							</ul>
						 </li>
						 <li>
						  <label for="mylist-node2" class="quick-links">Secondary</label>
						  <input type="checkbox" id="mylist-node2" />
						  <ul>
							   <li></li>
							   <li><a href="">Form One</a></li>
							  
								<li><a href="">Form Two</a></li>
								<li><a href="">Form Three</a></li>
								<li><a href="">Form Four</a></li>
									
								
							   
						  </ul>
						 </li>
						 
						
						 
					</ul>