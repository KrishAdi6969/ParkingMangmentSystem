<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Car Park Management System</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<?php
			include('inc/head.php');
			include('inc/css1.php');
	?>
</head>
<body>
	<section id="container">
	<?php
			include('inc/header.php');
						include('inc/connect.php');
						
	?>
	
	<section id="content">
	<div>
	<style>
    /* Page header */
    .phead {
        font-size: 24px;
        font-weight: bold;
        color: #ffffff;
        text-align: center;
        margin-bottom: 20px;
    }

    /* Form container */
    .form-container {
        width: 600px;
        background: #ffffff;
        padding: 10px;
        margin: auto;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    /* Table styling */
    table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;
    }

    th, td {
        padding: 12px;
        border: 1px solid #dddddd;
        text-align: left;
        font-weight: bold;
        color: #333333;
    }

    th {
        background-color: #f2f2f2;
    }

    /* Alternate row background color */
    tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    /* Checkbox styling */
    input[type="checkbox"] {
        margin-top: 3px;
    }

    /* Delete button */
    .btn-delete {
        display: block;
        width: 150px;
        margin: 0 auto;
        padding: 12px;
        background-color: #dc3545;
        color: #ffffff;
        border: none;
        border-radius: 5px;
        font-size: 16px;
        font-weight: bold;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    /* Delete button hover effect */
    .btn-delete:hover {
        background-color: #c82333;
    }
</style>

<p class="phead">Users</p>
<div class="form-container">
    <form method="post" action="delete.php">
        <table cellpadding="0" cellspacing="0" border="0">
            <thead>
                <tr>
                    <th>CHK</th>
                    <th>Name</th>
                    <th>Id No</th>
                    <th>Phone</th>
                    <th style="width: 100px;">Plate No</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $query = mysqli_query($connect, "SELECT * FROM users WHERE access='2'") or die(mysqli_error());
                while ($row = mysqli_fetch_array($query)) {
                    $id = $row['id'];
                ?>
                    <tr>
                        <td><input name="selector[]" type="checkbox" value="<?php echo $id; ?>"></td>
                        <td><?php echo $row['name'] ?></td>
                        <td><?php echo $row['id_no'] ?></td>
                        <td><?php echo $row['phone'] ?></td>
                        <td><?php echo $row['plate_no'] ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        <input type="submit" class="btn-delete" value="Delete" name="delete">
    </form>
</div>

	</section>
</body>
</html>