<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Car Park Management System</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<?php
			include('inc/head.php');
	?>
</head>
<head>
        <title>Car Parking Management System</title>
        <link rel="stylesheet" type="text/css" href="styles/style_index.css">

        <!--Google Fonts-->
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link rel="icon" href="assets/logos/title_icon.png" type="image/icon type">

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    </head>
<body>
	
	<?php
			
		include('inc/connect.php');
						
	?>
	<nav>
        <?php  
if (session_status() == PHP_SESSION_NONE) {
    session_start();
		if(isset($_SESSION['phone']))
			{
				
				
				} 
			else
			{
				//header("Location: index.php");
			}
}
 ?>
            <ul class="menu-bar">
                <div class="logo">
                    <a href="index.php">
                        <i class="material-icons">directions_car</i>This is ur admin
                    </a>
                </div>
                <li><a href="index.php">Users</a></li>
                <li><a href="bookings.php">Bookings</a></li>
                
                <li><a href="transactions.php">Transactions</a></li>
                <li><a href="messages.php">Messages</a></li>
                <?php if ($_SESSION['access']==0)  {  ?>
                <li><a href="manage.php">Manage Admins</a></li>
                <?php  } ?>	
            </ul>
        </nav>
		<div class="container">
	
	<div>
	<style>
    /* Page header */
    .phead {
        font-size: 24px;
        font-weight: bold;
        color: #ffffff;
        text-align: center;
        margin-bottom: 20px;
    }

    /* Form container */
    .form-container {
        max-width: 800px;
        margin: 0 auto;
        background: #f9f9f9;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    /* Table styling */
    table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;
    }

    th, td {
        padding: 12px;
        border: 1px solid #dddddd;
        text-align: left;
        font-weight: bold;
        color: #333333;
    }

    th {
        background-color: #f2f2f2;
    }

    /* Checkbox styling */
    input[type="checkbox"] {
        margin-top: 3px;
    }

    /* Delete button */
    .btn-delete {
        display: block;
        width: 150px;
        margin: 0 auto;
        padding: 12px;
        background-color: #dc3545;
        color: #ffffff;
        border: none;
        border-radius: 5px;
        font-size: 16px;
        font-weight: bold;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    /* Delete button hover effect */
    .btn-delete:hover {
        background-color: #c82333;
    }
</style>

<p class="phead">Street Booking</p>
<div class="form-container">
    <form method="post" action="deletebooking.php">
        <table cellpadding="0" cellspacing="0" border="0">
            <thead>
                <tr>
                    <th>CHK</th>
                    <th>Street</th>
                    <th>Date & Time</th>
                    <th>Car Plate No</th>
                    <th>Phone</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $query = mysqli_query($connect, "select * from zones") or die(mysql_error());
                while ($row = mysqli_fetch_array($query)) {
                    $id = $row['id'];
                ?>
                    <tr>
                        <td><input name="selector[]" type="checkbox" value="<?php echo $id; ?>"></td>
                        <td><?php echo $row['street'].$id ?></td>
                        <td><?php echo $row['d1'] ?></td>
                        <td><?php echo $row['platenumber'] ?></td>
                        <td><?php echo $row['phone'] ?></td>
                        <td><?php echo $row['status'] ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        <input type="submit" class="btn-delete" value="Delete" name="delete">
    </form>
</div>

							</div>
</body>
</html>